#!/bin/bash

# 색상 정의
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 로그 함수
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# root 권한 확인
if [ "$EUID" -ne 0 ]; then
    log_error "이 스크립트는 root 권한으로 실행해야 합니다."
    log_info "다음 명령어로 다시 실행해주세요: sudo $0"
    exit 1
fi

# 필요한 패키지 설치
log_info "필요한 시스템 패키지를 설치합니다..."
apt-get update
apt-get install -y mdadm smartmontools

# 실행 파일 설치
log_info "Ubuntu RAID CLI를 설치합니다..."
cp raid-cli /usr/local/bin/
chmod +x /usr/local/bin/raid-cli

log_info "설치가 완료되었습니다!"
log_info "이제 'raid-cli' 명령어를 사용할 수 있습니다."
